$(document).ready(function(){
    console.log("DOM READY")
})